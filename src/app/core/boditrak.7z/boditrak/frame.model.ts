export class Frame {
  id?: number;
  time?: string;
  readings: number[][] = [];
}
